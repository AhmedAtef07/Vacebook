<?php
// Database constants
define('DB_SERVER', "localhost");
define('DB_USER', "root");
define('DB_PASSWORD', "123");
define('DB_DATABASE', "countries");
define('DB_DRIVER', "mysql");