<!doctype html>

<html lang="en">
<head>
  <title>Auto-complete tutorial</title>
  <meta name="description" content="The HTML5 Herald">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="auto-complete.js"></script>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  	<input type="text" value="" placeholder="Search" id="keyword" list="datalist">
  	<div id="results">
  	</div>
</body>
</html>